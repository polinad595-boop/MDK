﻿namespace ClassroomBooking.Configuration
{
    public class AppSettings
    {
        public string AppTitle { get; set; } = "Classroom Booking";
        public string WorkDayStart { get; set; } = "08:00";
        public string WorkDayEnd { get; set; } = "20:00";
        public int MinBookingMinutes { get; set; } = 30;
        public bool AllowUnavailableRooms { get; set; } = false;
        public string StatusMessage { get; set; } = "Учебный режим";

        // Расширенные параметры (для максимальной оценки)
        public int MaxBookingHours { get; set; } = 4;
        public bool AllowPastDates { get; set; } = false;
        public bool AdminMode { get; set; } = false;
    }
}