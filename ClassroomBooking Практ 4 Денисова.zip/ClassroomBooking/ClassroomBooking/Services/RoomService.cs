﻿using System.Collections.Generic;
using ClassroomBooking.Models;

namespace ClassroomBooking.Services
{
    public class RoomService
    {
        private List<Room> _rooms = new List<Room>();

        public RoomService()
        {
            _rooms.Add(new Room { Id = 1, Number = "301", ComputerCount = 20, IsAvailable = true, MaxGroupSize = 25 });
            _rooms.Add(new Room { Id = 2, Number = "302", ComputerCount = 15, IsAvailable = true, MaxGroupSize = 20 });
            _rooms.Add(new Room { Id = 3, Number = "303", ComputerCount = 25, IsAvailable = true, MaxGroupSize = 30 });

            _rooms.Add(new Room { Id = 4, Number = "305", ComputerCount = 10, IsAvailable = false, MaxGroupSize = 15 });
        }

        public List<Room> GetAllRooms()
        {
            return _rooms;
        }

        public Room GetRoomById(int id)
        {
            return _rooms.Find(r => r.Id == id);
        }
    }
}