﻿using System;
using System.Collections.Generic;
using System.Linq;
using ClassroomBooking.Models;

namespace ClassroomBooking.Services
{
    public class BookingService
    {
        private List<Booking> _bookings = new List<Booking>();
        private int _nextId = 1;

        public bool CreateBooking(int userId, int roomId, DateTime date, TimeSpan startTime, TimeSpan endTime)
        {
            if (startTime >= endTime)
                return false;

            var conflict = _bookings.Any(b =>
                b.RoomId == roomId &&
                b.Date.Date == date.Date &&
                b.StartTime < endTime &&
                b.EndTime > startTime);

            if (conflict)
                return false;

            _bookings.Add(new Booking
            {
                Id = _nextId++,
                UserId = userId,
                RoomId = roomId,
                Date = date,
                StartTime = startTime,
                EndTime = endTime
            });

            return true;
        }

        public List<Booking> GetAllBookings()
        {
            return _bookings;
        }
    }
}