﻿using System.Collections.Generic;
using ClassroomBooking.Models;

namespace ClassroomBooking.Services
{
    public class UserService
    {
        private List<User> _users = new List<User>();

        public UserService()
        {
            _users.Add(new User { Id = 1, Name = "Иван Петров", Login = "ipetrov", Role = "Студент" });
            _users.Add(new User { Id = 2, Name = "Мария Сидорова", Login = "msidorova", Role = "Преподаватель" });
            _users.Add(new User { Id = 3, Name = "Алексей Козлов", Login = "akozlov", Role = "Студент" });
        }

        public List<User> GetAllUsers()
        {
            return _users;
        }

        public User GetUserById(int id)
        {
            return _users.Find(u => u.Id == id);
        }
    }
}